
let carrito = [];

function agregarAlCarrito(producto, precio) {
    carrito.push({ producto, precio });
    alert(producto + " ha sido agregado al carrito.");
}
